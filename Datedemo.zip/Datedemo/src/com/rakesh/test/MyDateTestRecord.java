package com.rakesh.test;

import com.rakesh.pojo.MyDate;

public class MyDateTestRecord {
	public MyDate startDate;
	public  MyDate endDate;
	public  long expectedResult;
	
	public MyDateTestRecord(MyDate startDate, MyDate endDate, long expectedResult) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.expectedResult = expectedResult;
	}
	
	

}
