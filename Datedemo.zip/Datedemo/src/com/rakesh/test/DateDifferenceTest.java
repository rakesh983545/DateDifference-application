package com.rakesh.test;

import java.util.ArrayList;

import com.rakesh.pojo.MyDate;
import com.rakesh.service.DateDifferenceProvider;

public class DateDifferenceTest {
	
	
	
	public static void main(String[] args)
	{
		ArrayList<MyDateTestRecord> testData=new ArrayList<MyDateTestRecord>();
		
		testData.add(new MyDateTestRecord(new MyDate(4, 6, 2011),new MyDate(4, 6, 2011),0));
				
		/*testData.add(new MyDateTestRecord(new MyDate(3, 2, 2012),
				new MyDate(3,5,2012),3));*/
		
		
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),new MyDate(4,18,2011),12));
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),	new MyDate(5,18,2011),42));
			
		
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),	new MyDate(6,18,2011),73));
		
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),	new MyDate(12,18,2011),256));
	
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),new MyDate(12,18,2012),622));
				
		
		/*
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),
				new MyDate(12,18,2013),987));
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),
				new MyDate(12,18,2113),37511));
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),
				new MyDate(12,18,2413),147084));
		testData.add(new MyDateTestRecord(new MyDate(4, 06, 2011),
				new MyDate(12,18,2813),293181));
		testData.add(new MyDateTestRecord(new MyDate(1, 06, 2011),
				new MyDate(3,6,2011),59));
		testData.add(new MyDateTestRecord(new MyDate(1, 06, 2012),
				new MyDate(3,6,2012),60));
		testData.add(new MyDateTestRecord(new MyDate(2,06,2012),
				new MyDate(3, 06, 2012),29));
		testData.add(new MyDateTestRecord(new MyDate(1, 22, 2012),
				new MyDate(11,15,2012),298));
		testData.add(new MyDateTestRecord(new MyDate(2, 06, 2012),
				new MyDate(12,06,2012),304));
		*/
	
		
		
		for(MyDateTestRecord testCase:testData)
		{
			MyDate startDate=testCase.startDate;
			MyDate endDate=testCase.endDate;
			long expectedResult=testCase.expectedResult;
			long obtainedResult=DateDifferenceProvider.getDateDifference(startDate, endDate);
			
			
			if(expectedResult==obtainedResult)
			
				System.out.println("Test"+(1 + testData.lastIndexOf(testCase)) + "Passed"+ " "+ obtainedResult +" = obtainedResult" + expectedResult+" = expectedResult");
			else
				System.err.println("Test"+(1 + testData.lastIndexOf(testCase)) + "Failed"+ obtainedResult +" = obtainedResult"+ expectedResult+" = expectedResult");
		}
		
				
				
		
		
	}

}
