package com.rakesh.pojo;

public class MyDate {

	private int dd,mm,yyyy;

	public MyDate(int mm, int dd, int yyyy) {
		super();
		this.mm = mm;
		this.dd = dd;
		this.yyyy = yyyy;
	}

	public int getMm() {
		return mm;
	}
	public int getDd() {
		return dd;
	}

	public int getYyyy() {
		return yyyy;
	}
}
