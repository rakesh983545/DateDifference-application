package com.rakesh.service;

import com.rakesh.pojo.MyDate;
import com.rakesh.test.MyDateTestRecord;

public class DateDifferenceProvider {

	static int month[]= {0,31,28,31,30,31,30,31,31,30,31,30,31};
	public static int getDateDifference(MyDate startDate, MyDate endDate)
	{
	
		if(sameMonth(startDate, endDate) && sameYear(startDate, endDate) && sameDay(startDate, endDate))
			return 0;
		else if(sameMonth(startDate, endDate) && sameYear(startDate, endDate))
		return endDate.getDd() - startDate.getDd();
		
		else if( !sameMonth(startDate, endDate) && sameYear(startDate, endDate)){

		return (daysInCurrentMonth(startDate)+daysPassedCurrentMonth(endDate)+daysBetweenConcreteMonth(startDate, endDate));
		
		}
		else
		{
			if(daysRemainingCurrentYear(startDate)+daysPassedCurrentYear(endDate)+daysInInterveningYear(startDate, endDate)>730)
				return daysRemainingCurrentYear(startDate)+daysPassedCurrentYear(endDate)+daysInInterveningYear(startDate, endDate)-1;
			else
				return daysRemainingCurrentYear(startDate)+daysPassedCurrentYear(endDate)+daysInInterveningYear(startDate, endDate);
		}
		
	}
	
	
	private static boolean sameDay(MyDate startDate,MyDate endDate)
	{
		if(startDate.getDd()==endDate.getDd())
			return true;
		else
			return false;
	}
	
	
	private static boolean sameMonth(MyDate startDate,MyDate endDate)
	{
		if(startDate.getMm()==endDate.getMm())
			return true;
		else
			return false;
		
					
	}
	
	private static boolean sameYear(MyDate startDate,MyDate endDate)
	{
		if(startDate.getYyyy()==endDate.getYyyy())
			return true;
		else
			return false;
		
					
	}
	
	
	private static int daysInCurrentMonth(MyDate startDate)
	{
		int month[]= {0,31,28,31,30,31,30,31,31,30,31,30,31};
		if(isLeapYear(startDate.getYyyy()) && startDate.getMm()==2)
		{
			month[2]=29;
		}
		return month[startDate.getMm()]-startDate.getDd();
	}
	
	private static int daysPassedCurrentMonth(MyDate startDate)
	{
		int month[]= {0,31,28,31,30,31,30,31,31,30,31,30,31};
		if(isLeapYear(startDate.getYyyy()) && startDate.getMm()==2)
		{
			month[2]=29;
		}
		return startDate.getDd();
	}
	
	private static int daysBetweenConcreteMonth(MyDate startDate,MyDate endDate)
	{
		int month[]= {0,31,28,31,30,31,30,31,31,30,31,30,31};
		if(isLeapYear(startDate.getYyyy()) || isLeapYear(startDate.getYyyy()) )
		{
			month[2]=29;
		}
		int differenceMonth=0;
		
		for(int monDiff=startDate.getMm()+1;monDiff<=endDate.getMm()-1;monDiff++) {
			
			
			differenceMonth+=month[monDiff];
			
		}
		return differenceMonth;
	}
	
	private static int daysPassedCurrentYear(MyDate startDate)
	{
		MyDate a=new MyDate(startDate.getDd(), startDate.getMm(), startDate.getYyyy());
		//System.out.println(daysPassedCurrentMonth(startDate)+"\t"+daysBetweenConcreteMonth(new MyDate(0, 0, 0), a));
		return daysPassedCurrentMonth(startDate)+daysBetweenConcreteMonth(new MyDate(0, 0, 0), a);
	}
	
	private static int daysRemainingCurrentYear(MyDate startDate)
	{
		
		return daysInCurrentMonth(startDate)+daysBetweenConcreteMonth(startDate,new MyDate(0, 13, 0));
	}
	private static int daysInInterveningYear(MyDate startDate,MyDate endDate)
	{
		int sum=0;
		for(int i=startDate.getYyyy()+1;i<endDate.getYyyy();i++)
		{
			if(isLeapYear(i))
				sum+=366;
			else
				sum+=365;
		}
		return sum;
	}
	
	private static boolean isLeapYear(int year)
	{
		if(year % 400 == 0)
        {
           return true;
        }
        else if (year % 100 == 0)
        {
            return false;
        }
        else if(year % 4 == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
	}
	
	public static void main(String[] args) {
		MyDate a=new MyDate(6, 1, 2011);
		MyDate b=new MyDate(6, 3 , 2011);
		System.out.println(getDateDifference(a, b));
	}

}
